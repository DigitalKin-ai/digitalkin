import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SignalAction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SIGNAL_ACTION_UNSPECIFIED: _ClassVar[SignalAction]
    SIGNAL_ACTION_CANCEL: _ClassVar[SignalAction]
    SIGNAL_ACTION_PAUSE: _ClassVar[SignalAction]

class StreamState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    STREAM_STATE_UNSPECIFIED: _ClassVar[StreamState]
    STREAM_STATE_STARTING: _ClassVar[StreamState]
    STREAM_STATE_RUNNING: _ClassVar[StreamState]
    STREAM_STATE_PAUSING: _ClassVar[StreamState]
    STREAM_STATE_STOPPING: _ClassVar[StreamState]
    STREAM_STATE_COMPLETED: _ClassVar[StreamState]
    STREAM_STATE_FAILED: _ClassVar[StreamState]
    STREAM_STATE_CANCELLED: _ClassVar[StreamState]
SIGNAL_ACTION_UNSPECIFIED: SignalAction
SIGNAL_ACTION_CANCEL: SignalAction
SIGNAL_ACTION_PAUSE: SignalAction
STREAM_STATE_UNSPECIFIED: StreamState
STREAM_STATE_STARTING: StreamState
STREAM_STATE_RUNNING: StreamState
STREAM_STATE_PAUSING: StreamState
STREAM_STATE_STOPPING: StreamState
STREAM_STATE_COMPLETED: StreamState
STREAM_STATE_FAILED: StreamState
STREAM_STATE_CANCELLED: StreamState

class StartStreamRequest(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    INPUT_FIELD_NUMBER: _ClassVar[int]
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    input: _struct_pb2.Struct
    setup_id: str
    mission_id: str
    def __init__(self, task_id: _Optional[str] = ..., input: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., setup_id: _Optional[str] = ..., mission_id: _Optional[str] = ...) -> None: ...

class StartStreamResponse(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ACCEPTED_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    accepted: bool
    def __init__(self, task_id: _Optional[str] = ..., accepted: _Optional[bool] = ...) -> None: ...

class ProduceStreamRequest(_message.Message):
    __slots__ = ()
    INIT_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    init: ProduceStreamInit
    output: ProduceStreamOutput
    def __init__(self, init: _Optional[_Union[ProduceStreamInit, _Mapping]] = ..., output: _Optional[_Union[ProduceStreamOutput, _Mapping]] = ...) -> None: ...

class ProduceStreamInit(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    def __init__(self, task_id: _Optional[str] = ...) -> None: ...

class ProduceStreamOutput(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    data: _struct_pb2.Struct
    def __init__(self, task_id: _Optional[str] = ..., data: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class ProduceStreamResponse(_message.Message):
    __slots__ = ()
    DATA_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    data: ProduceStreamData
    status: StreamStatus
    def __init__(self, data: _Optional[_Union[ProduceStreamData, _Mapping]] = ..., status: _Optional[_Union[StreamStatus, _Mapping]] = ...) -> None: ...

class ProduceStreamData(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    data: _struct_pb2.Struct
    def __init__(self, task_id: _Optional[str] = ..., data: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class ConsumeStreamRequest(_message.Message):
    __slots__ = ()
    INIT_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    init: ConsumeStreamInit
    data: ConsumeStreamData
    def __init__(self, init: _Optional[_Union[ConsumeStreamInit, _Mapping]] = ..., data: _Optional[_Union[ConsumeStreamData, _Mapping]] = ...) -> None: ...

class ConsumeStreamInit(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    FROM_SEQ_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    from_seq: int
    def __init__(self, task_id: _Optional[str] = ..., from_seq: _Optional[int] = ...) -> None: ...

class ConsumeStreamData(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    data: _struct_pb2.Struct
    def __init__(self, task_id: _Optional[str] = ..., data: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class GatewayResponse(_message.Message):
    __slots__ = ()
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    HEARTBEAT_FIELD_NUMBER: _ClassVar[int]
    output: StreamOutput
    status: StreamStatus
    error: StreamError
    heartbeat: ServerHeartbeat
    def __init__(self, output: _Optional[_Union[StreamOutput, _Mapping]] = ..., status: _Optional[_Union[StreamStatus, _Mapping]] = ..., error: _Optional[_Union[StreamError, _Mapping]] = ..., heartbeat: _Optional[_Union[ServerHeartbeat, _Mapping]] = ...) -> None: ...

class ClientSignalRequest(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    action: SignalAction
    def __init__(self, task_id: _Optional[str] = ..., action: _Optional[_Union[SignalAction, str]] = ...) -> None: ...

class ClientSignalResponse(_message.Message):
    __slots__ = ()
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    success: bool
    task_id: str
    def __init__(self, success: _Optional[bool] = ..., task_id: _Optional[str] = ...) -> None: ...

class StreamOutput(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SEQ_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    job_id: str
    data: _struct_pb2.Struct
    seq: int
    timestamp: _timestamp_pb2.Timestamp
    def __init__(self, task_id: _Optional[str] = ..., job_id: _Optional[str] = ..., data: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., seq: _Optional[int] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class StreamStatus(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    job_id: str
    state: StreamState
    message: str
    def __init__(self, task_id: _Optional[str] = ..., job_id: _Optional[str] = ..., state: _Optional[_Union[StreamState, str]] = ..., message: _Optional[str] = ...) -> None: ...

class StreamError(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    job_id: str
    code: int
    message: str
    def __init__(self, task_id: _Optional[str] = ..., job_id: _Optional[str] = ..., code: _Optional[int] = ..., message: _Optional[str] = ...) -> None: ...

class ServerHeartbeat(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    timestamp: _timestamp_pb2.Timestamp
    def __init__(self, task_id: _Optional[str] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class Checkpoint(_message.Message):
    __slots__ = ()
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LAST_SEQ_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    mission_id: str
    setup_id: str
    setup_version_id: str
    status: str
    last_seq: int
    state: _struct_pb2.Struct
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, task_id: _Optional[str] = ..., mission_id: _Optional[str] = ..., setup_id: _Optional[str] = ..., setup_version_id: _Optional[str] = ..., status: _Optional[str] = ..., last_seq: _Optional[int] = ..., state: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...
