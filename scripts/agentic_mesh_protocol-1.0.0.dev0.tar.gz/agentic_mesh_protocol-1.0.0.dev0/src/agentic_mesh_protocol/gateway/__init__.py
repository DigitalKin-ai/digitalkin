"""Gateway service protocol definitions."""
