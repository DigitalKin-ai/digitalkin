from agentic_mesh_protocol.module.v1 import module_enums_pb2 as _module_enums_pb2
from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from agentic_mesh_protocol.pagination.v1 import pagination_pb2 as _pagination_pb2
from agentic_mesh_protocol.registry.v1 import registry_enums_pb2 as _registry_enums_pb2
from agentic_mesh_protocol.registry.v1 import registry_messages_pb2 as _registry_messages_pb2
from agentic_mesh_protocol.setup.v1 import setup_enums_pb2 as _setup_enums_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RegisterModuleRequest(_message.Message):
    __slots__ = ()
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    module_id: str
    address: str
    version: str
    port: int
    def __init__(self, module_id: _Optional[str] = ..., address: _Optional[str] = ..., version: _Optional[str] = ..., port: _Optional[int] = ...) -> None: ...

class RegisterModuleResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _registry_messages_pb2.RegistryResult
    def __init__(self, result: _Optional[_Union[_registry_messages_pb2.RegistryResult, _Mapping]] = ...) -> None: ...

class HeartbeatRequest(_message.Message):
    __slots__ = ()
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    module_id: str
    def __init__(self, module_id: _Optional[str] = ...) -> None: ...

class HeartbeatResponse(_message.Message):
    __slots__ = ()
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _module_enums_pb2.ModuleStatus
    def __init__(self, status: _Optional[_Union[_module_enums_pb2.ModuleStatus, str]] = ...) -> None: ...

class SearchSetupsRequest(_message.Message):
    __slots__ = ()
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    MODULE_IDS_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MODULE_TYPES_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    query: str
    pagination: _pagination_pb2.PaginationRequest
    module_ids: _containers.RepeatedScalarFieldContainer[str]
    visibility: _containers.RepeatedScalarFieldContainer[_registry_enums_pb2.Visibility]
    status: _containers.RepeatedScalarFieldContainer[_setup_enums_pb2.SetupStatus]
    module_types: _containers.RepeatedScalarFieldContainer[_module_enums_pb2.ModuleType]
    def __init__(self, organization_id: _Optional[str] = ..., query: _Optional[str] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationRequest, _Mapping]] = ..., module_ids: _Optional[_Iterable[str]] = ..., visibility: _Optional[_Iterable[_Union[_registry_enums_pb2.Visibility, str]]] = ..., status: _Optional[_Iterable[_Union[_setup_enums_pb2.SetupStatus, str]]] = ..., module_types: _Optional[_Iterable[_Union[_module_enums_pb2.ModuleType, str]]] = ...) -> None: ...

class SearchSetupsResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_registry_messages_pb2.RegistryResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_registry_messages_pb2.RegistryResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...

class SearchModulesRequest(_message.Message):
    __slots__ = ()
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_FIELD_NUMBER: _ClassVar[int]
    MODULE_TYPES_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    query: str
    pagination: _pagination_pb2.PaginationRequest
    visibility: _containers.RepeatedScalarFieldContainer[_registry_enums_pb2.Visibility]
    module_types: _containers.RepeatedScalarFieldContainer[_module_enums_pb2.ModuleType]
    status: _containers.RepeatedScalarFieldContainer[_module_enums_pb2.ModuleStatus]
    def __init__(self, organization_id: _Optional[str] = ..., query: _Optional[str] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationRequest, _Mapping]] = ..., visibility: _Optional[_Iterable[_Union[_registry_enums_pb2.Visibility, str]]] = ..., module_types: _Optional[_Iterable[_Union[_module_enums_pb2.ModuleType, str]]] = ..., status: _Optional[_Iterable[_Union[_module_enums_pb2.ModuleStatus, str]]] = ...) -> None: ...

class SearchModulesResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_registry_messages_pb2.RegistryResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_registry_messages_pb2.RegistryResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...

class GetSetupRequest(_message.Message):
    __slots__ = ()
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    setup_id: str
    def __init__(self, setup_id: _Optional[str] = ...) -> None: ...

class GetSetupResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _registry_messages_pb2.RegistryResult
    def __init__(self, result: _Optional[_Union[_registry_messages_pb2.RegistryResult, _Mapping]] = ...) -> None: ...

class GetModuleRequest(_message.Message):
    __slots__ = ()
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    module_id: str
    def __init__(self, module_id: _Optional[str] = ...) -> None: ...

class GetModuleResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _registry_messages_pb2.RegistryResult
    def __init__(self, result: _Optional[_Union[_registry_messages_pb2.RegistryResult, _Mapping]] = ...) -> None: ...

class GetModuleStatusRequest(_message.Message):
    __slots__ = ()
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    module_id: str
    def __init__(self, module_id: _Optional[str] = ...) -> None: ...

class GetModuleStatusResponse(_message.Message):
    __slots__ = ()
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _module_enums_pb2.ModuleStatus
    def __init__(self, status: _Optional[_Union[_module_enums_pb2.ModuleStatus, str]] = ...) -> None: ...
