import datetime

from agentic_mesh_protocol.module.v1 import module_enums_pb2 as _module_enums_pb2
from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from agentic_mesh_protocol.registry.v1 import registry_enums_pb2 as _registry_enums_pb2
from agentic_mesh_protocol.setup.v1 import setup_enums_pb2 as _setup_enums_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ModuleDescriptor(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    DOCUMENTATION_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    INPUT_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    SETUP_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    SECRET_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    COST_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    id: str
    organization_id: str
    owner_id: str
    name: str
    version: str
    address: str
    documentation: str
    port: int
    type: _module_enums_pb2.ModuleType
    status: _module_enums_pb2.ModuleStatus
    visibility: _registry_enums_pb2.Visibility
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    input_schema: _struct_pb2.Struct
    output_schema: _struct_pb2.Struct
    setup_schema: _struct_pb2.Struct
    secret_schema: _struct_pb2.Struct
    cost_schema: _struct_pb2.Struct
    def __init__(self, id: _Optional[str] = ..., organization_id: _Optional[str] = ..., owner_id: _Optional[str] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., address: _Optional[str] = ..., documentation: _Optional[str] = ..., port: _Optional[int] = ..., type: _Optional[_Union[_module_enums_pb2.ModuleType, str]] = ..., status: _Optional[_Union[_module_enums_pb2.ModuleStatus, str]] = ..., visibility: _Optional[_Union[_registry_enums_pb2.Visibility, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., input_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., output_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., setup_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., secret_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., cost_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class SetupDescriptor(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    CARD_ID_FIELD_NUMBER: _ClassVar[int]
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DOCUMENTATION_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    MODULE_FIELD_NUMBER: _ClassVar[int]
    id: str
    organization_id: str
    owner_id: str
    card_id: str
    module_id: str
    setup_version_id: str
    name: str
    documentation: str
    setup_version: str
    status: _setup_enums_pb2.SetupStatus
    visibility: _registry_enums_pb2.Visibility
    config: _struct_pb2.Struct
    module: ModuleDescriptor
    def __init__(self, id: _Optional[str] = ..., organization_id: _Optional[str] = ..., owner_id: _Optional[str] = ..., card_id: _Optional[str] = ..., module_id: _Optional[str] = ..., setup_version_id: _Optional[str] = ..., name: _Optional[str] = ..., documentation: _Optional[str] = ..., setup_version: _Optional[str] = ..., status: _Optional[_Union[_setup_enums_pb2.SetupStatus, str]] = ..., visibility: _Optional[_Union[_registry_enums_pb2.Visibility, str]] = ..., config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., module: _Optional[_Union[ModuleDescriptor, _Mapping]] = ...) -> None: ...

class RegistryResult(_message.Message):
    __slots__ = ()
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MODULE_DESCRIPTOR_FIELD_NUMBER: _ClassVar[int]
    SETUP_DESCRIPTOR_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    identifier: str
    success: bool
    module_descriptor: ModuleDescriptor
    setup_descriptor: SetupDescriptor
    error: _bulk_pb2.OperationError
    def __init__(self, identifier: _Optional[str] = ..., success: _Optional[bool] = ..., module_descriptor: _Optional[_Union[ModuleDescriptor, _Mapping]] = ..., setup_descriptor: _Optional[_Union[SetupDescriptor, _Mapping]] = ..., error: _Optional[_Union[_bulk_pb2.OperationError, _Mapping]] = ...) -> None: ...
