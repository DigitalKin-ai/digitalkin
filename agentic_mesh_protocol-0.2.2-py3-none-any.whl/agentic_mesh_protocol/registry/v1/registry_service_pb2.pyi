from agentic_mesh_protocol.registry.v1 import registry_dto_pb2 as _registry_dto_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
