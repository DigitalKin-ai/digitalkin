from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class Visibility(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    VISIBILITY_UNSPECIFIED: _ClassVar[Visibility]
    PUBLIC: _ClassVar[Visibility]
    PRIVATE: _ClassVar[Visibility]
    INTERNAL: _ClassVar[Visibility]
VISIBILITY_UNSPECIFIED: Visibility
PUBLIC: Visibility
PRIVATE: Visibility
INTERNAL: Visibility
