"""Version information for agentic_mesh_protocol package."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("agentic-mesh-protocol")
except PackageNotFoundError:
    __version__ = "bump-my-version>=1.2.6"
