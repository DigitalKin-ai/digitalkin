from agentic_mesh_protocol.user_profile.v1 import user_profile_messages_pb2 as _user_profile_messages_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetUserProfileRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    def __init__(self, mission_id: _Optional[str] = ...) -> None: ...

class GetUserProfileResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _user_profile_messages_pb2.UserProfileResult
    def __init__(self, result: _Optional[_Union[_user_profile_messages_pb2.UserProfileResult, _Mapping]] = ...) -> None: ...
