import datetime

from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from agentic_mesh_protocol.setup.v1 import setup_enums_pb2 as _setup_enums_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SetupVersion(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    id: str
    setup_id: str
    version: str
    created_at: _timestamp_pb2.Timestamp
    content: _struct_pb2.Struct
    def __init__(self, id: _Optional[str] = ..., setup_id: _Optional[str] = ..., version: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., content: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class Setup(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CURRENT_SETUP_VERSION_FIELD_NUMBER: _ClassVar[int]
    id: str
    organization_id: str
    owner_id: str
    module_id: str
    name: str
    status: _setup_enums_pb2.SetupStatus
    current_setup_version: SetupVersion
    def __init__(self, id: _Optional[str] = ..., organization_id: _Optional[str] = ..., owner_id: _Optional[str] = ..., module_id: _Optional[str] = ..., name: _Optional[str] = ..., status: _Optional[_Union[_setup_enums_pb2.SetupStatus, str]] = ..., current_setup_version: _Optional[_Union[SetupVersion, _Mapping]] = ...) -> None: ...

class SetupResult(_message.Message):
    __slots__ = ()
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    SETUP_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    identifier: str
    success: bool
    setup: Setup
    version: SetupVersion
    error: _bulk_pb2.OperationError
    def __init__(self, identifier: _Optional[str] = ..., success: _Optional[bool] = ..., setup: _Optional[_Union[Setup, _Mapping]] = ..., version: _Optional[_Union[SetupVersion, _Mapping]] = ..., error: _Optional[_Union[_bulk_pb2.OperationError, _Mapping]] = ...) -> None: ...
