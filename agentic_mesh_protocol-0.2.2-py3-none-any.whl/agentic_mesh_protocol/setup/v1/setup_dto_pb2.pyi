from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from agentic_mesh_protocol.pagination.v1 import pagination_pb2 as _pagination_pb2
from agentic_mesh_protocol.setup.v1 import setup_enums_pb2 as _setup_enums_pb2
from agentic_mesh_protocol.setup.v1 import setup_messages_pb2 as _setup_messages_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateSetupRequest(_message.Message):
    __slots__ = ()
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CURRENT_SETUP_VERSION_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    owner_id: str
    module_id: str
    name: str
    status: _setup_enums_pb2.SetupStatus
    current_setup_version: _setup_messages_pb2.SetupVersion
    def __init__(self, organization_id: _Optional[str] = ..., owner_id: _Optional[str] = ..., module_id: _Optional[str] = ..., name: _Optional[str] = ..., status: _Optional[_Union[_setup_enums_pb2.SetupStatus, str]] = ..., current_setup_version: _Optional[_Union[_setup_messages_pb2.SetupVersion, _Mapping]] = ...) -> None: ...

class CreateSetupResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _setup_messages_pb2.SetupResult
    def __init__(self, result: _Optional[_Union[_setup_messages_pb2.SetupResult, _Mapping]] = ...) -> None: ...

class GetSetupRequest(_message.Message):
    __slots__ = ()
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    setup_id: str
    version: str
    def __init__(self, setup_id: _Optional[str] = ..., version: _Optional[str] = ...) -> None: ...

class GetSetupResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _setup_messages_pb2.SetupResult
    def __init__(self, result: _Optional[_Union[_setup_messages_pb2.SetupResult, _Mapping]] = ...) -> None: ...

class UpdateSetupRequest(_message.Message):
    __slots__ = ()
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CURRENT_SETUP_VERSION_FIELD_NUMBER: _ClassVar[int]
    setup_id: str
    owner_id: str
    name: str
    status: _setup_enums_pb2.SetupStatus
    current_setup_version: _setup_messages_pb2.SetupVersion
    def __init__(self, setup_id: _Optional[str] = ..., owner_id: _Optional[str] = ..., name: _Optional[str] = ..., status: _Optional[_Union[_setup_enums_pb2.SetupStatus, str]] = ..., current_setup_version: _Optional[_Union[_setup_messages_pb2.SetupVersion, _Mapping]] = ...) -> None: ...

class UpdateSetupResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _setup_messages_pb2.SetupResult
    def __init__(self, result: _Optional[_Union[_setup_messages_pb2.SetupResult, _Mapping]] = ...) -> None: ...

class DeleteSetupRequest(_message.Message):
    __slots__ = ()
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    setup_id: str
    def __init__(self, setup_id: _Optional[str] = ...) -> None: ...

class DeleteSetupResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _setup_messages_pb2.SetupResult
    def __init__(self, result: _Optional[_Union[_setup_messages_pb2.SetupResult, _Mapping]] = ...) -> None: ...

class ListSetupsRequest(_message.Message):
    __slots__ = ()
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    owner_id: str
    pagination: _pagination_pb2.PaginationRequest
    def __init__(self, organization_id: _Optional[str] = ..., owner_id: _Optional[str] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationRequest, _Mapping]] = ...) -> None: ...

class ListSetupsResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_setup_messages_pb2.SetupResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_setup_messages_pb2.SetupResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...
