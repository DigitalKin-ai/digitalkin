from agentic_mesh_protocol.setup.v1 import setup_version_dto_pb2 as _setup_version_dto_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
