from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from agentic_mesh_protocol.pagination.v1 import pagination_pb2 as _pagination_pb2
from agentic_mesh_protocol.setup.v1 import setup_messages_pb2 as _setup_messages_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateSetupVersionRequest(_message.Message):
    __slots__ = ()
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    setup_id: str
    version: str
    content: _struct_pb2.Struct
    def __init__(self, setup_id: _Optional[str] = ..., version: _Optional[str] = ..., content: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class CreateSetupVersionResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _setup_messages_pb2.SetupResult
    def __init__(self, result: _Optional[_Union[_setup_messages_pb2.SetupResult, _Mapping]] = ...) -> None: ...

class GetSetupVersionRequest(_message.Message):
    __slots__ = ()
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    setup_version_id: str
    def __init__(self, setup_version_id: _Optional[str] = ...) -> None: ...

class GetSetupVersionResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _setup_messages_pb2.SetupResult
    def __init__(self, result: _Optional[_Union[_setup_messages_pb2.SetupResult, _Mapping]] = ...) -> None: ...

class SearchSetupVersionsRequest(_message.Message):
    __slots__ = ()
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    setup_id: str
    version: str
    pagination: _pagination_pb2.PaginationRequest
    def __init__(self, setup_id: _Optional[str] = ..., version: _Optional[str] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationRequest, _Mapping]] = ...) -> None: ...

class SearchSetupVersionsResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_setup_messages_pb2.SetupResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_setup_messages_pb2.SetupResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...

class UpdateSetupVersionRequest(_message.Message):
    __slots__ = ()
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    setup_version_id: str
    version: str
    content: _struct_pb2.Struct
    def __init__(self, setup_version_id: _Optional[str] = ..., version: _Optional[str] = ..., content: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class UpdateSetupVersionResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _setup_messages_pb2.SetupResult
    def __init__(self, result: _Optional[_Union[_setup_messages_pb2.SetupResult, _Mapping]] = ...) -> None: ...

class DeleteSetupVersionRequest(_message.Message):
    __slots__ = ()
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    setup_version_id: str
    def __init__(self, setup_version_id: _Optional[str] = ...) -> None: ...

class DeleteSetupVersionResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _setup_messages_pb2.SetupResult
    def __init__(self, result: _Optional[_Union[_setup_messages_pb2.SetupResult, _Mapping]] = ...) -> None: ...
