from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class SetupStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SETUP_STATUS_UNSPECIFIED: _ClassVar[SetupStatus]
    DRAFT: _ClassVar[SetupStatus]
    VALIDATING: _ClassVar[SetupStatus]
    READY: _ClassVar[SetupStatus]
    PAUSED: _ClassVar[SetupStatus]
    FAILED: _ClassVar[SetupStatus]
    ARCHIVED: _ClassVar[SetupStatus]
    NEEDS_CONFIGURATION: _ClassVar[SetupStatus]
    CONFIGURATION_FAILED: _ClassVar[SetupStatus]
    CONFIGURATION_SUCCEEDED: _ClassVar[SetupStatus]
SETUP_STATUS_UNSPECIFIED: SetupStatus
DRAFT: SetupStatus
VALIDATING: SetupStatus
READY: SetupStatus
PAUSED: SetupStatus
FAILED: SetupStatus
ARCHIVED: SetupStatus
NEEDS_CONFIGURATION: SetupStatus
CONFIGURATION_FAILED: SetupStatus
CONFIGURATION_SUCCEEDED: SetupStatus
