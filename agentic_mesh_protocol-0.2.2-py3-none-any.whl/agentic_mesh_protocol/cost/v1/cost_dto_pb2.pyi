from agentic_mesh_protocol.cost.v1 import cost_enums_pb2 as _cost_enums_pb2
from agentic_mesh_protocol.cost.v1 import cost_messages_pb2 as _cost_messages_pb2
from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from agentic_mesh_protocol.pagination.v1 import pagination_pb2 as _pagination_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateCostRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    COST_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    RATE_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    setup_version_id: str
    name: str
    cost: float
    quantity: float
    rate: float
    unit: str
    type: _cost_enums_pb2.CostType
    def __init__(self, mission_id: _Optional[str] = ..., setup_version_id: _Optional[str] = ..., name: _Optional[str] = ..., cost: _Optional[float] = ..., quantity: _Optional[float] = ..., rate: _Optional[float] = ..., unit: _Optional[str] = ..., type: _Optional[_Union[_cost_enums_pb2.CostType, str]] = ...) -> None: ...

class CreateCostResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _cost_messages_pb2.CostResult
    def __init__(self, result: _Optional[_Union[_cost_messages_pb2.CostResult, _Mapping]] = ...) -> None: ...

class ListCostsRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    pagination: _pagination_pb2.PaginationRequest
    filter: _cost_messages_pb2.CostFilter
    def __init__(self, mission_id: _Optional[str] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationRequest, _Mapping]] = ..., filter: _Optional[_Union[_cost_messages_pb2.CostFilter, _Mapping]] = ...) -> None: ...

class ListCostsResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_cost_messages_pb2.CostResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_cost_messages_pb2.CostResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...

class ListCostConfigRequest(_message.Message):
    __slots__ = ()
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    setup_version_id: str
    pagination: _pagination_pb2.PaginationRequest
    def __init__(self, setup_version_id: _Optional[str] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationRequest, _Mapping]] = ...) -> None: ...

class ListCostConfigResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_cost_messages_pb2.CostResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_cost_messages_pb2.CostResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...

class SetCostConfigRequest(_message.Message):
    __slots__ = ()
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    CONFIGS_FIELD_NUMBER: _ClassVar[int]
    setup_version_id: str
    configs: _containers.RepeatedCompositeFieldContainer[_cost_messages_pb2.CostConfig]
    def __init__(self, setup_version_id: _Optional[str] = ..., configs: _Optional[_Iterable[_Union[_cost_messages_pb2.CostConfig, _Mapping]]] = ...) -> None: ...

class SetCostConfigResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_cost_messages_pb2.CostResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_cost_messages_pb2.CostResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...
