from agentic_mesh_protocol.cost.v1 import cost_enums_pb2 as _cost_enums_pb2
from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Cost(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    COST_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    RATE_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    setup_version_id: str
    name: str
    cost: float
    quantity: float
    rate: float
    unit: str
    type: _cost_enums_pb2.CostType
    def __init__(self, mission_id: _Optional[str] = ..., setup_version_id: _Optional[str] = ..., name: _Optional[str] = ..., cost: _Optional[float] = ..., quantity: _Optional[float] = ..., rate: _Optional[float] = ..., unit: _Optional[str] = ..., type: _Optional[_Union[_cost_enums_pb2.CostType, str]] = ...) -> None: ...

class CostFilter(_message.Message):
    __slots__ = ()
    TYPES_FIELD_NUMBER: _ClassVar[int]
    NAMES_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_IDS_FIELD_NUMBER: _ClassVar[int]
    types: _containers.RepeatedScalarFieldContainer[_cost_enums_pb2.CostType]
    names: _containers.RepeatedScalarFieldContainer[str]
    setup_version_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, types: _Optional[_Iterable[_Union[_cost_enums_pb2.CostType, str]]] = ..., names: _Optional[_Iterable[str]] = ..., setup_version_ids: _Optional[_Iterable[str]] = ...) -> None: ...

class CostConfig(_message.Message):
    __slots__ = ()
    NAME_FIELD_NUMBER: _ClassVar[int]
    COST_TYPE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    RATE_FIELD_NUMBER: _ClassVar[int]
    name: str
    cost_type: _cost_enums_pb2.CostType
    description: str
    unit: str
    rate: float
    def __init__(self, name: _Optional[str] = ..., cost_type: _Optional[_Union[_cost_enums_pb2.CostType, str]] = ..., description: _Optional[str] = ..., unit: _Optional[str] = ..., rate: _Optional[float] = ...) -> None: ...

class CostResult(_message.Message):
    __slots__ = ()
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    COST_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    identifier: str
    success: bool
    cost: Cost
    config: CostConfig
    error: _bulk_pb2.OperationError
    def __init__(self, identifier: _Optional[str] = ..., success: _Optional[bool] = ..., cost: _Optional[_Union[Cost, _Mapping]] = ..., config: _Optional[_Union[CostConfig, _Mapping]] = ..., error: _Optional[_Union[_bulk_pb2.OperationError, _Mapping]] = ...) -> None: ...
