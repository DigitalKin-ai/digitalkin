from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class CostType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    COST_TYPE_UNSPECIFIED: _ClassVar[CostType]
    TOKEN_INPUT: _ClassVar[CostType]
    TOKEN_OUTPUT: _ClassVar[CostType]
    API_CALL: _ClassVar[CostType]
    STORAGE: _ClassVar[CostType]
    TIME: _ClassVar[CostType]
    OTHER: _ClassVar[CostType]
COST_TYPE_UNSPECIFIED: CostType
TOKEN_INPUT: CostType
TOKEN_OUTPUT: CostType
API_CALL: CostType
STORAGE: CostType
TIME: CostType
OTHER: CostType
