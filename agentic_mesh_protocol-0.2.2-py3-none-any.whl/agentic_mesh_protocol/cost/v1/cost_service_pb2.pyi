from agentic_mesh_protocol.cost.v1 import cost_dto_pb2 as _cost_dto_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
