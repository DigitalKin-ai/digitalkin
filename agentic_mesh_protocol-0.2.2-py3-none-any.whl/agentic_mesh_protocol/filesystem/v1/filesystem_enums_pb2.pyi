from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class FileType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FILE_TYPE_UNSPECIFIED: _ClassVar[FileType]
    DOCUMENT: _ClassVar[FileType]
    IMAGE: _ClassVar[FileType]
    VIDEO: _ClassVar[FileType]
    AUDIO: _ClassVar[FileType]
    ARCHIVE: _ClassVar[FileType]
    CODE: _ClassVar[FileType]
    OTHER: _ClassVar[FileType]

class FileStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FILE_STATUS_UNSPECIFIED: _ClassVar[FileStatus]
    UPLOADING: _ClassVar[FileStatus]
    ACTIVE: _ClassVar[FileStatus]
    PROCESSING: _ClassVar[FileStatus]
    ARCHIVED: _ClassVar[FileStatus]
    DELETED: _ClassVar[FileStatus]
FILE_TYPE_UNSPECIFIED: FileType
DOCUMENT: FileType
IMAGE: FileType
VIDEO: FileType
AUDIO: FileType
ARCHIVE: FileType
CODE: FileType
OTHER: FileType
FILE_STATUS_UNSPECIFIED: FileStatus
UPLOADING: FileStatus
ACTIVE: FileStatus
PROCESSING: FileStatus
ARCHIVED: FileStatus
DELETED: FileStatus
