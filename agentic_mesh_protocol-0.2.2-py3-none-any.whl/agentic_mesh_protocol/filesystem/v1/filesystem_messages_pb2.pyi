import datetime

from agentic_mesh_protocol.filesystem.v1 import filesystem_enums_pb2 as _filesystem_enums_pb2
from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class File(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    CHECKSUM_FIELD_NUMBER: _ClassVar[int]
    STORAGE_URI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    id: str
    context: str
    name: str
    content_type: str
    checksum: str
    storage_uri: str
    url: str
    size_bytes: int
    content: bytes
    status: _filesystem_enums_pb2.FileStatus
    type: _filesystem_enums_pb2.FileType
    metadata: _struct_pb2.Struct
    def __init__(self, id: _Optional[str] = ..., context: _Optional[str] = ..., name: _Optional[str] = ..., content_type: _Optional[str] = ..., checksum: _Optional[str] = ..., storage_uri: _Optional[str] = ..., url: _Optional[str] = ..., size_bytes: _Optional[int] = ..., content: _Optional[bytes] = ..., status: _Optional[_Union[_filesystem_enums_pb2.FileStatus, str]] = ..., type: _Optional[_Union[_filesystem_enums_pb2.FileType, str]] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class FileFilter(_message.Message):
    __slots__ = ()
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    CONTENT_TYPE_PREFIX_FIELD_NUMBER: _ClassVar[int]
    PREFIX_FIELD_NUMBER: _ClassVar[int]
    CONTENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    MIN_SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    MAX_SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AFTER_FIELD_NUMBER: _ClassVar[int]
    CREATED_BEFORE_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AFTER_FIELD_NUMBER: _ClassVar[int]
    UPDATED_BEFORE_FIELD_NUMBER: _ClassVar[int]
    NAMES_FIELD_NUMBER: _ClassVar[int]
    IDS_FIELD_NUMBER: _ClassVar[int]
    TYPES_FIELD_NUMBER: _ClassVar[int]
    context: str
    content_type_prefix: str
    prefix: str
    content_type: str
    min_size_bytes: int
    max_size_bytes: int
    status: _filesystem_enums_pb2.FileStatus
    created_after: _timestamp_pb2.Timestamp
    created_before: _timestamp_pb2.Timestamp
    updated_after: _timestamp_pb2.Timestamp
    updated_before: _timestamp_pb2.Timestamp
    names: _containers.RepeatedScalarFieldContainer[str]
    ids: _containers.RepeatedScalarFieldContainer[str]
    types: _containers.RepeatedScalarFieldContainer[_filesystem_enums_pb2.FileType]
    def __init__(self, context: _Optional[str] = ..., content_type_prefix: _Optional[str] = ..., prefix: _Optional[str] = ..., content_type: _Optional[str] = ..., min_size_bytes: _Optional[int] = ..., max_size_bytes: _Optional[int] = ..., status: _Optional[_Union[_filesystem_enums_pb2.FileStatus, str]] = ..., created_after: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., created_before: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_after: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_before: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., names: _Optional[_Iterable[str]] = ..., ids: _Optional[_Iterable[str]] = ..., types: _Optional[_Iterable[_Union[_filesystem_enums_pb2.FileType, str]]] = ...) -> None: ...

class UploadFileData(_message.Message):
    __slots__ = ()
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    REPLACE_IF_EXISTS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    context: str
    name: str
    content_type: str
    content: bytes
    replace_if_exists: bool
    status: _filesystem_enums_pb2.FileStatus
    type: _filesystem_enums_pb2.FileType
    metadata: _struct_pb2.Struct
    def __init__(self, context: _Optional[str] = ..., name: _Optional[str] = ..., content_type: _Optional[str] = ..., content: _Optional[bytes] = ..., replace_if_exists: _Optional[bool] = ..., status: _Optional[_Union[_filesystem_enums_pb2.FileStatus, str]] = ..., type: _Optional[_Union[_filesystem_enums_pb2.FileType, str]] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class FileResult(_message.Message):
    __slots__ = ()
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    identifier: str
    success: bool
    content: bytes
    file: File
    error: _bulk_pb2.OperationError
    def __init__(self, identifier: _Optional[str] = ..., success: _Optional[bool] = ..., content: _Optional[bytes] = ..., file: _Optional[_Union[File, _Mapping]] = ..., error: _Optional[_Union[_bulk_pb2.OperationError, _Mapping]] = ...) -> None: ...
