from agentic_mesh_protocol.filesystem.v1 import filesystem_enums_pb2 as _filesystem_enums_pb2
from agentic_mesh_protocol.filesystem.v1 import filesystem_messages_pb2 as _filesystem_messages_pb2
from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from agentic_mesh_protocol.pagination.v1 import pagination_pb2 as _pagination_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetFileRequest(_message.Message):
    __slots__ = ()
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_CONTENT_FIELD_NUMBER: _ClassVar[int]
    context: str
    id: str
    include_content: bool
    def __init__(self, context: _Optional[str] = ..., id: _Optional[str] = ..., include_content: _Optional[bool] = ...) -> None: ...

class GetFileResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _filesystem_messages_pb2.FileResult
    def __init__(self, result: _Optional[_Union[_filesystem_messages_pb2.FileResult, _Mapping]] = ...) -> None: ...

class ListFilesRequest(_message.Message):
    __slots__ = ()
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_CONTENT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    context: str
    include_content: bool
    pagination: _pagination_pb2.PaginationRequest
    filters: _filesystem_messages_pb2.FileFilter
    def __init__(self, context: _Optional[str] = ..., include_content: _Optional[bool] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationRequest, _Mapping]] = ..., filters: _Optional[_Union[_filesystem_messages_pb2.FileFilter, _Mapping]] = ...) -> None: ...

class ListFilesResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_filesystem_messages_pb2.FileResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_filesystem_messages_pb2.FileResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...

class UploadFilesRequest(_message.Message):
    __slots__ = ()
    FILES_FIELD_NUMBER: _ClassVar[int]
    files: _containers.RepeatedCompositeFieldContainer[_filesystem_messages_pb2.UploadFileData]
    def __init__(self, files: _Optional[_Iterable[_Union[_filesystem_messages_pb2.UploadFileData, _Mapping]]] = ...) -> None: ...

class UploadFilesResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_filesystem_messages_pb2.FileResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_filesystem_messages_pb2.FileResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...

class UpdateFileRequest(_message.Message):
    __slots__ = ()
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    NEW_NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    context: str
    id: str
    content: bytes
    new_name: str
    content_type: str
    type: _filesystem_enums_pb2.FileType
    status: _filesystem_enums_pb2.FileStatus
    metadata: _struct_pb2.Struct
    def __init__(self, context: _Optional[str] = ..., id: _Optional[str] = ..., content: _Optional[bytes] = ..., new_name: _Optional[str] = ..., content_type: _Optional[str] = ..., type: _Optional[_Union[_filesystem_enums_pb2.FileType, str]] = ..., status: _Optional[_Union[_filesystem_enums_pb2.FileStatus, str]] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class UpdateFileResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _filesystem_messages_pb2.FileResult
    def __init__(self, result: _Optional[_Union[_filesystem_messages_pb2.FileResult, _Mapping]] = ...) -> None: ...

class DeleteFilesRequest(_message.Message):
    __slots__ = ()
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    FORCE_FIELD_NUMBER: _ClassVar[int]
    PERMANENT_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    context: str
    force: bool
    permanent: bool
    filters: _filesystem_messages_pb2.FileFilter
    def __init__(self, context: _Optional[str] = ..., force: _Optional[bool] = ..., permanent: _Optional[bool] = ..., filters: _Optional[_Union[_filesystem_messages_pb2.FileFilter, _Mapping]] = ...) -> None: ...

class DeleteFilesResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_filesystem_messages_pb2.FileResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_filesystem_messages_pb2.FileResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...
