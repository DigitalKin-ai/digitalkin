from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from agentic_mesh_protocol.pagination.v1 import pagination_pb2 as _pagination_pb2
from agentic_mesh_protocol.storage.v1 import storage_enums_pb2 as _storage_enums_pb2
from agentic_mesh_protocol.storage.v1 import storage_messages_pb2 as _storage_messages_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateRecordRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    COLLECTION_FIELD_NUMBER: _ClassVar[int]
    RECORD_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    collection: str
    record_id: str
    data_type: _storage_enums_pb2.DataType
    data: _struct_pb2.Struct
    def __init__(self, mission_id: _Optional[str] = ..., collection: _Optional[str] = ..., record_id: _Optional[str] = ..., data_type: _Optional[_Union[_storage_enums_pb2.DataType, str]] = ..., data: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class CreateRecordResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _storage_messages_pb2.StorageResult
    def __init__(self, result: _Optional[_Union[_storage_messages_pb2.StorageResult, _Mapping]] = ...) -> None: ...

class GetRecordRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    COLLECTION_FIELD_NUMBER: _ClassVar[int]
    RECORD_ID_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    collection: str
    record_id: str
    def __init__(self, mission_id: _Optional[str] = ..., collection: _Optional[str] = ..., record_id: _Optional[str] = ...) -> None: ...

class GetRecordResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _storage_messages_pb2.StorageResult
    def __init__(self, result: _Optional[_Union[_storage_messages_pb2.StorageResult, _Mapping]] = ...) -> None: ...

class UpdateRecordRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    COLLECTION_FIELD_NUMBER: _ClassVar[int]
    RECORD_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    collection: str
    record_id: str
    data: _struct_pb2.Struct
    def __init__(self, mission_id: _Optional[str] = ..., collection: _Optional[str] = ..., record_id: _Optional[str] = ..., data: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class UpdateRecordResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _storage_messages_pb2.StorageResult
    def __init__(self, result: _Optional[_Union[_storage_messages_pb2.StorageResult, _Mapping]] = ...) -> None: ...

class DeleteRecordRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    COLLECTION_FIELD_NUMBER: _ClassVar[int]
    RECORD_ID_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    collection: str
    record_id: str
    def __init__(self, mission_id: _Optional[str] = ..., collection: _Optional[str] = ..., record_id: _Optional[str] = ...) -> None: ...

class DeleteRecordResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _storage_messages_pb2.StorageResult
    def __init__(self, result: _Optional[_Union[_storage_messages_pb2.StorageResult, _Mapping]] = ...) -> None: ...

class ListRecordsRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    COLLECTION_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    collection: str
    pagination: _pagination_pb2.PaginationRequest
    def __init__(self, mission_id: _Optional[str] = ..., collection: _Optional[str] = ..., pagination: _Optional[_Union[_pagination_pb2.PaginationRequest, _Mapping]] = ...) -> None: ...

class ListRecordsResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    BULK_FIELD_NUMBER: _ClassVar[int]
    result: _containers.RepeatedCompositeFieldContainer[_storage_messages_pb2.StorageResult]
    bulk: _bulk_pb2.BulkResponse
    def __init__(self, result: _Optional[_Iterable[_Union[_storage_messages_pb2.StorageResult, _Mapping]]] = ..., bulk: _Optional[_Union[_bulk_pb2.BulkResponse, _Mapping]] = ...) -> None: ...

class DeleteCollectionRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    COLLECTION_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    collection: str
    def __init__(self, mission_id: _Optional[str] = ..., collection: _Optional[str] = ...) -> None: ...

class DeleteCollectionResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _storage_messages_pb2.StorageResult
    def __init__(self, result: _Optional[_Union[_storage_messages_pb2.StorageResult, _Mapping]] = ...) -> None: ...
