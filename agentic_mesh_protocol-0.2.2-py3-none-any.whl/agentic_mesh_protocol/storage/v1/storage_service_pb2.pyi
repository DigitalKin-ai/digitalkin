from agentic_mesh_protocol.storage.v1 import storage_dto_pb2 as _storage_dto_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
