from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class DataType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DATA_TYPE_UNSPECIFIED: _ClassVar[DataType]
    OUTPUT: _ClassVar[DataType]
    VIEW: _ClassVar[DataType]
    LOGS: _ClassVar[DataType]
    OTHER: _ClassVar[DataType]
DATA_TYPE_UNSPECIFIED: DataType
OUTPUT: DataType
VIEW: DataType
LOGS: DataType
OTHER: DataType
