from agentic_mesh_protocol.pagination.v1 import bulk_pb2 as _bulk_pb2
from agentic_mesh_protocol.setup.v1 import setup_messages_pb2 as _setup_messages_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ModuleResult(_message.Message):
    __slots__ = ()
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    INPUT_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    SETUP_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    SECRET_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    COST_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    CONFIG_SETUP_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    SELECT_INPUT_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    identifier: str
    success: bool
    input_schema: _struct_pb2.Struct
    output_schema: _struct_pb2.Struct
    setup_schema: _struct_pb2.Struct
    secret_schema: _struct_pb2.Struct
    cost_schema: _struct_pb2.Struct
    config_setup_schema: _struct_pb2.Struct
    select_input_schema: _struct_pb2.Struct
    output: _struct_pb2.Struct
    setup_version: _setup_messages_pb2.SetupVersion
    error: _bulk_pb2.OperationError
    def __init__(self, identifier: _Optional[str] = ..., success: _Optional[bool] = ..., input_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., output_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., setup_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., secret_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., cost_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., config_setup_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., select_input_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., output: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., setup_version: _Optional[_Union[_setup_messages_pb2.SetupVersion, _Mapping]] = ..., error: _Optional[_Union[_bulk_pb2.OperationError, _Mapping]] = ...) -> None: ...
