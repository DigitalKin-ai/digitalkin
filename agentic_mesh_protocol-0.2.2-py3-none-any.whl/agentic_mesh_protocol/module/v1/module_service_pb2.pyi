from agentic_mesh_protocol.module.v1 import module_dto_pb2 as _module_dto_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
