from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class ModuleStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MODULE_STATUS_UNSPECIFIED: _ClassVar[ModuleStatus]
    READY: _ClassVar[ModuleStatus]
    ACTIVE: _ClassVar[ModuleStatus]
    ARCHIVED: _ClassVar[ModuleStatus]

class ModuleType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MODULE_TYPE_UNSPECIFIED: _ClassVar[ModuleType]
    ARCHETYPE: _ClassVar[ModuleType]
    TOOL: _ClassVar[ModuleType]
MODULE_STATUS_UNSPECIFIED: ModuleStatus
READY: ModuleStatus
ACTIVE: ModuleStatus
ARCHIVED: ModuleStatus
MODULE_TYPE_UNSPECIFIED: ModuleType
ARCHETYPE: ModuleType
TOOL: ModuleType
