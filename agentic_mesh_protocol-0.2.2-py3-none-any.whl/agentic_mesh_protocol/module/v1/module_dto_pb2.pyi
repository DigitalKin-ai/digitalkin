from agentic_mesh_protocol.module.v1 import module_messages_pb2 as _module_messages_pb2
from agentic_mesh_protocol.setup.v1 import setup_messages_pb2 as _setup_messages_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetModuleInputRequest(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    LLM_FORMAT_FIELD_NUMBER: _ClassVar[int]
    id: str
    llm_format: bool
    def __init__(self, id: _Optional[str] = ..., llm_format: _Optional[bool] = ...) -> None: ...

class GetModuleInputResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _module_messages_pb2.ModuleResult
    def __init__(self, result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...

class GetModuleOutputRequest(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    LLM_FORMAT_FIELD_NUMBER: _ClassVar[int]
    id: str
    llm_format: bool
    def __init__(self, id: _Optional[str] = ..., llm_format: _Optional[bool] = ...) -> None: ...

class GetModuleOutputResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _module_messages_pb2.ModuleResult
    def __init__(self, result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...

class GetModuleSetupRequest(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    LLM_FORMAT_FIELD_NUMBER: _ClassVar[int]
    id: str
    llm_format: bool
    def __init__(self, id: _Optional[str] = ..., llm_format: _Optional[bool] = ...) -> None: ...

class GetModuleSetupResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _module_messages_pb2.ModuleResult
    def __init__(self, result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...

class GetModuleSecretRequest(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    LLM_FORMAT_FIELD_NUMBER: _ClassVar[int]
    id: str
    llm_format: bool
    def __init__(self, id: _Optional[str] = ..., llm_format: _Optional[bool] = ...) -> None: ...

class GetModuleSecretResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _module_messages_pb2.ModuleResult
    def __init__(self, result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...

class GetConfigSetupModuleRequest(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    LLM_FORMAT_FIELD_NUMBER: _ClassVar[int]
    id: str
    llm_format: bool
    def __init__(self, id: _Optional[str] = ..., llm_format: _Optional[bool] = ...) -> None: ...

class GetConfigSetupModuleResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _module_messages_pb2.ModuleResult
    def __init__(self, result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...

class ConfigSetupModuleRequest(_message.Message):
    __slots__ = ()
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    SETUP_VERSION_FIELD_NUMBER: _ClassVar[int]
    mission_id: str
    content: _struct_pb2.Struct
    setup_version: _setup_messages_pb2.SetupVersion
    def __init__(self, mission_id: _Optional[str] = ..., content: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., setup_version: _Optional[_Union[_setup_messages_pb2.SetupVersion, _Mapping]] = ...) -> None: ...

class ConfigSetupModuleResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _module_messages_pb2.ModuleResult
    def __init__(self, result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...

class StartModuleRequest(_message.Message):
    __slots__ = ()
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    MISSION_ID_FIELD_NUMBER: _ClassVar[int]
    INPUT_FIELD_NUMBER: _ClassVar[int]
    setup_id: str
    mission_id: str
    input: _struct_pb2.Struct
    def __init__(self, setup_id: _Optional[str] = ..., mission_id: _Optional[str] = ..., input: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class StartModuleResponse(_message.Message):
    __slots__ = ()
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    job_id: str
    result: _module_messages_pb2.ModuleResult
    def __init__(self, job_id: _Optional[str] = ..., result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...

class StopModuleRequest(_message.Message):
    __slots__ = ()
    JOB_ID_FIELD_NUMBER: _ClassVar[int]
    job_id: str
    def __init__(self, job_id: _Optional[str] = ...) -> None: ...

class StopModuleResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _module_messages_pb2.ModuleResult
    def __init__(self, result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...

class GetModuleSelectInputRequest(_message.Message):
    __slots__ = ()
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    module_id: str
    def __init__(self, module_id: _Optional[str] = ...) -> None: ...

class GetModuleSelectInputResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _module_messages_pb2.ModuleResult
    def __init__(self, result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...

class GetModuleCostRequest(_message.Message):
    __slots__ = ()
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    LLM_FORMAT_FIELD_NUMBER: _ClassVar[int]
    module_id: str
    llm_format: bool
    def __init__(self, module_id: _Optional[str] = ..., llm_format: _Optional[bool] = ...) -> None: ...

class GetModuleCostResponse(_message.Message):
    __slots__ = ()
    RESULT_FIELD_NUMBER: _ClassVar[int]
    result: _module_messages_pb2.ModuleResult
    def __init__(self, result: _Optional[_Union[_module_messages_pb2.ModuleResult, _Mapping]] = ...) -> None: ...
